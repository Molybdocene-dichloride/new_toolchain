//
// Created by zheka on 18/09/26.
//

#ifndef HORIZON_DEFINITIONS_H
#define HORIZON_DEFINITIONS_H

#define API __attribute__((used))

#endif //HORIZON_DEFINITIONS_H
