ItemRegistry.createItem("grinPowder", {name: "grin_powder", icon: "grin_powder"});
ItemRegistry.createItem("hops", {name: "hops", icon: "hops"});
ItemRegistry.createItem("weed", {name: "weed", icon: "weed"});
