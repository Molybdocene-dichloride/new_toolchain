ItemRegistry.createItem("ashes", {name: "ashes", icon: "ashes"});
ItemRegistry.createItem("slag", {name: "slag", icon: "slag"});
ItemRegistry.createItem("bioChaff", {name: "bio_chaff", icon: "bio_chaff"});