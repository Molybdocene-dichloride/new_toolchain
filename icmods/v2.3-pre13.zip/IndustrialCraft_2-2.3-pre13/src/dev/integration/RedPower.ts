ModAPI.addAPICallback("RedCore", (api: any) => {
	api.Integration.addDeployerItem(ItemID.cableTin0);
	api.Integration.addDeployerItem(ItemID.cableTin1);
	api.Integration.addDeployerItem(ItemID.cableCopper0);
	api.Integration.addDeployerItem(ItemID.cableCopper1);
	api.Integration.addDeployerItem(ItemID.cableGold0);
	api.Integration.addDeployerItem(ItemID.cableGold1);
	api.Integration.addDeployerItem(ItemID.cableGold2);
	api.Integration.addDeployerItem(ItemID.cableIron0);
	api.Integration.addDeployerItem(ItemID.cableIron1);
	api.Integration.addDeployerItem(ItemID.cableIron2);
	api.Integration.addDeployerItem(ItemID.cableIron3);
	api.Integration.addDeployerItem(ItemID.cableOptic);
});