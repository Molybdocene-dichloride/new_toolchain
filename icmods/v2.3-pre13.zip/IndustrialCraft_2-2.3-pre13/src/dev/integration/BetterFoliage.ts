ModAPI.addAPICallback("BetterFoliageLeaves", function(BetterFoliage: any) {
	BetterFoliage.setupLeavesModel(BlockID.rubberTreeLeaves, -1, ["rubber_tree_leaves", 0]);
});