namespace Agriculture {
	export type SeedBagStackData = {
		id: number;
		data: CropTileData;
		extra: ItemExtraData;
	}
}
