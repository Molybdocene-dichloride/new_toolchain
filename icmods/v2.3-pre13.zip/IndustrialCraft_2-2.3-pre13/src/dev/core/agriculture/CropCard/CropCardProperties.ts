namespace Agriculture {
	export type CropCardProperties = {
		tier: number;
		chemistry: number;
		consumable: number;
		defensive: number;
		colorful: number;
		weed: number;
	}
}
