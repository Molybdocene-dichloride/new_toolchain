ConfigureMultiplayer({
	isClientOnly: false
});

Launch();